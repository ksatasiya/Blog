<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                
                <div class="panel-body">
                    <table class="table">
                            <tr>
                                <th>checkNo</th>
                                <th>Date</th>
                                <th>Check Issue Id</th>
                                <th>Amount Check</th>
                                <th>Date Of Deposit</th>
                                <th>Amount Deposit</th>
                                <th>Bank Name</th>
                                <th>Branch Name</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            <?php echo e(dd($data)); ?>

                        <?php foreach($data as $row): ?>
                            <tr>
                                <td><?php echo e($row->checkNo); ?></td>
                                <td><?php echo e($row->date); ?></td>
                                <td><?php echo e($row->checkIssueTO); ?></td>
                                <td><?php echo e($row->amountCheck); ?></td>
                                <td><?php echo e($row->dateOfDiposit); ?></td>
                                <td><?php echo e($row->anountDeposit); ?></td>
                                <td><?php echo e($row->bankName); ?></td>
                                <td><?php echo e($row->branchName); ?></td>
                                <td><a href="<?php echo e(route('/$row->id')); ?>">Edit</a></td>
                                <td><a href="#">Delete</a></td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>