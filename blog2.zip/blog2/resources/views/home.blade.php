@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>
                
                <div class="panel-body">
                    <table class="table">
                            <tr>
                                <th>checkNo</th>
                                <th>Date</th>
                                <th>Check Issue Id</th>
                                <th>Amount Check</th>
                                <th>Date Of Deposit</th>
                                <th>Amount Deposit</th>
                                <th>Bank Name</th>
                                <th>Branch Name</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                            {{dd($data)}}
                        @foreach($data as $row)
                            <tr>
                                <td>{{$row->checkNo}}</td>
                                <td>{{$row->date}}</td>
                                <td>{{$row->checkIssueTO}}</td>
                                <td>{{$row->amountCheck}}</td>
                                <td>{{$row->dateOfDiposit}}</td>
                                <td>{{$row->anountDeposit}}</td>
                                <td>{{$row->bankName}}</td>
                                <td>{{$row->branchName}}</td>
                                <td><a href="{{ route('/$row->id') }}">Edit</a></td>
                                <td><a href="#">Delete</a></td>
                            </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
