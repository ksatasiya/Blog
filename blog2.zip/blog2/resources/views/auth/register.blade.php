@extends('layouts.app')

@section('content')
<link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
    
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,400,300,700">
        <link type="text/css" rel="stylesheet" href="http://fonts.googleapis.com/css?family=Oswald:400,700,300">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/jquery-ui-1.10.4.custom/css/ui-lightness/jquery-ui-1.10.4.custom.min.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/font-awesome/css/font-awesome.min.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/bootstrap/css/bootstrap.min.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/animate.css/animate.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/jquery-pace/pace.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/iCheck/skins/all.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/jquery-notific8/jquery.notific8.min.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/vendors/bootstrap-daterangepicker/daterangepicker-bs3.css">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/css/themes/style1/orange-blue.css" class="default-style">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/css/themes/style1/orange-blue.css" id="theme-change" class="style-change color-change">
        <link type="text/css" rel="stylesheet" href="http://m-preview.com/accounts/public/assets/css/style-responsive.css">

        <script src="http://m-preview.com/accounts/public/assets/js/jquery-1.10.2.min.js"></script>

        <script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<script src="http://m-preview.com/accounts/public/assets/js/jquery-1.10.2.min.js"></script>
<script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>
<div class="container">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="{{ url('/register') }}">
                        {{ csrf_field() }}
                    
                        <div class="form-group col-sm-12">
                            <div class="form-group{{ $errors->has('checkNo') ? ' has-error' : '' }} col-sm-6">
                                <label for="checkNo" class="col-md-4 control-label">Check No</label>
                                <div class="col-md-8">
                                    <input id="checkNo" type="number" class="form-control" name="checkNo" value="{{ old('checkNo') }}">
                                    @if ($errors->has('checkNo'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('checkNo') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group{{ $errors->has('date') ? ' has-error' : '' }} col-sm-6">
                                <label for="date" class="col-md-4 control-label">Date</label>
                                <div class="col-md-8">
                                    <input id="date" type="string" class="form-control" name="date" value="{{ old('date') }}">
                                    @if ($errors->has('date'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('date') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-sm-12">

                            <div class="form-group{{ $errors->has('checkIssueTO') ? ' has-error' : '' }} col-sm-6">
                                <label for="password" class="col-md-4 control-label">Check Issues To</label>

                                <div class="col-md-8">
                                    <input id="checkIssueTO" type="text" class="form-control" name="checkIssueTO" value="{{ old('checkIssueTO') }}">

                                    @if ($errors->has('checkIssueTO'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('checkIssueTO') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>

                            <div class="form-group{{ $errors->has('amountCheck') ? ' has-error' : '' }} col-lg-6">
                                <label for="amountCheck" class="col-md-4 control-label">Amount Of Check</label>

                                <div class="col-md-8">
                                    <input id="amountCheck" type="number" class="form-control" name="amountCheck" value="{{ old('amountCheck') }}">

                                    @if ($errors->has('amountCheck'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('amountCheck') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="form-group{{ $errors->has('dateOfDiposit') ? ' has-error' : '' }} col-lg-6">
                                <label for="number" class="col-md-4 control-label">Date Of Deposit</label>

                                <div class="col-md-8">
                                    <input id="dateOfDiposit" type="string" class="form-control" name="dateOfDiposit" value="{{ old('dateOfDiposit') }}">

                                    @if ($errors->has('dateOfDiposit'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('dateOfDiposit') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                            <div class="form-group{{ $errors->has('anountDeposit') ? ' has-error' : '' }} col-lg-6">
                                <label for="anountDeposit" class="col-md-4 control-label">Amount of Deposit</label>

                                <div class="col-md-8">
                                    <input id="anountDeposit" type="number" class="form-control" name="anountDeposit" value="{{ old('anountDeposit') }}">

                                    @if ($errors->has('anountDeposit'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('anountDeposit') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="form-group{{ $errors->has('bankName') ? ' has-error' : '' }} col-lg-6">
                                <label for="bankName" class="col-md-4 control-label">Bank</label>

                                <div class="col-md-8">
                                    <input id="bankName" type="text" class="form-control" name="bankName" value="{{ old('bankName') }}" >

                                    @if ($errors->has('bankName'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('bankName') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        

                            <div class="form-group{{ $errors->has('branchName') ? ' has-error' : '' }} col-lg-6">
                                <label for="branchName" class="col-md-4 control-label">Branch</label>

                                <div class="col-md-8">
                                    <input id="branchName" type="text" class="form-control" name="branchName" value="{{ old('branchName') }}">

                                    @if ($errors->has('branchName'))
                                        <span class="help-block">
                                            <strong>{{ $errors->first('branchName') }}</strong>
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 ">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Register
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
          $(function() {
            $( "#dateOfDiposit" ).datepicker();
            $( "#date " ).datepicker();            
          });
        </script>

        <script src="http://m-preview.com/accounts/public/assets/js/jquery-migrate-1.2.1.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/jquery-ui.js"></script><!--loading bootstrap js-->
        <script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap/js/bootstrap.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/bootstrap-hover-dropdown/bootstrap-hover-dropdown.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/html5shiv.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/respond.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/metisMenu/jquery.metisMenu.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/slimScroll/jquery.slimscroll.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/jquery-cookie/jquery.cookie.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/iCheck/icheck.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/iCheck/custom.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/jquery-notific8/jquery.notific8.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/jquery.menu.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/jquery-pace/pace.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/holder/holder.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/responsive-tabs/responsive-tabs.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/jquery-news-ticker/jquery.newsTicker.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/moment/moment.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/calendar/zabuto_calendar.min.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/main.js"></script><!--LOADING SCRIPTS FOR PAGE-->
        <script src="http://m-preview.com/accounts/public/assets/vendors/intro.js/intro.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/vendors/intro.js/intro.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/index.js"></script>
        <script src="http://m-preview.com/accounts/public/assets/js/entries.js"></script>    
        <script>
@endsection
